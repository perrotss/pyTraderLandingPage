module.exports = {
  semi: false,
  singleQuote: true,
  htmlWhitespaceSensitivity: 'ignore',
}
