<script setup lang="ts">
import { workoutPricingPlans } from '/@src/data/pages/workout'

import {
  pricingBlockC,
  pricingBlockCProps,
  pricingBlockCSample,
} from '/@src/data/docs/advanced/pricing/blockC'
</script>

<template>
  <Section id="block-c-demo" bordered-bottom>
    <Container>
      <DemoTitle
        title="Block C"
        subtitle="Advanced block C variation 1"
        link="block-c-props"
      />

      <div class="py-4"></div>

      <PricingDuo
        title="Our plans"
        subtitle="Duplexque isdem diebus acciderat malum, quod et Theophilum insontem
            atrox interceperat casus."
        :plans="workoutPricingPlans"
        rounded
        polka-dots
      />
    </Container>
  </Section>

  <Section id="block-c-props" bordered-bottom>
    <Container>
      <DemoTitle title="Block C Props" subtitle="Available props for block C" />

      <div class="py-4"></div>

      <DemoTabs>
        <template #code>
          <PrismCode language="html" :code="pricingBlockC" />
        </template>
        <template #props>
          <DemoProps :props="pricingBlockCProps.props" />
        </template>
        <template #sample>
          <PrismCode language="javascript" :code="pricingBlockCSample" />
        </template>
        <template #usage>
          <p class="paragraph rem-95">
            Vulk ships with stunning advanced Pricing blocks that you can use in
            any page. Each block comes with it's own styles and props. Use the
            props to build your own examples or use one of the prebuilt
            examples. Every block is natively supporting dark mode. See markup
            and props tab for more details about usage.
          </p>
        </template>
      </DemoTabs>
    </Container>
  </Section>
</template>
