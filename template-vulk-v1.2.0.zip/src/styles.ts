import '@purge-icons/generated'
import '@vueform/slider/themes/default.scss'
import 'vue3-carousel/dist/carousel.css'
import './scss/main.scss'
