export const nftMarquee = [
  {
    preview: 'data:image/gif;base64,replace_with_your_image',
    size: 1,
    url: '/',
  },
  {
    preview: 'data:image/gif;base64,replace_with_your_image',
    size: 2,
    url: '/',
  },
  {
    preview: 'data:image/gif;base64,replace_with_your_image',
    size: 3,
    url: '/',
  },
  {
    preview: 'data:image/gif;base64,replace_with_your_image',
    size: 1,
    url: '/',
  },
  {
    preview: 'data:image/gif;base64,replace_with_your_image',
    size: 4,
    url: '/',
  },
  {
    preview: 'data:image/gif;base64,replace_with_your_image',
    size: 2,
    url: '/',
  },
  {
    preview: 'data:image/gif;base64,replace_with_your_image',
    size: 5,
    url: '/',
  },
  {
    preview: 'data:image/gif;base64,replace_with_your_image',
    size: 1,
    url: '/',
  },
  {
    preview: 'data:image/gif;base64,replace_with_your_image',
    size: 3,
    url: '/',
  },
  {
    preview: 'data:image/gif;base64,replace_with_your_image',
    size: 2,
    url: '/',
  },
  {
    preview: 'data:image/gif;base64,replace_with_your_image',
    size: 6,
    url: '/',
  },
  {
    preview: 'data:image/gif;base64,replace_with_your_image',
    size: 2,
    url: '/',
  },
  {
    preview: 'data:image/gif;base64,replace_with_your_image',
    size: 4,
    url: '/',
  },
  {
    preview: 'data:image/gif;base64,replace_with_your_image',
    size: 3,
    url: '/',
  },
  {
    preview: 'data:image/gif;base64,replace_with_your_image',
    size: 5,
    url: '/',
  },
  {
    preview: 'data:image/gif;base64,replace_with_your_image',
    size: 1,
    url: '/',
  },
  {
    preview: 'data:image/gif;base64,replace_with_your_image',
    size: 5,
    url: '/',
  },
  {
    preview: 'data:image/gif;base64,replace_with_your_image',
    size: 2,
    url: '/',
  },
  {
    preview: 'data:image/gif;base64,replace_with_your_image',
    size: 2,
    url: '/',
  },
  {
    preview: 'data:image/gif;base64,replace_with_your_image',
    size: 4,
    url: '/',
  },
]
