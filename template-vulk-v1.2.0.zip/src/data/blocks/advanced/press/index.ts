export const press = [
  {
    id: 0,
    logo: '/assets/press/techcrunch.svg',
    darkLogo: '/assets/press/techcrunch-dark.svg',
    text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Illa tamen simplicia, vestra versuta. Negat esse eam, inquit, propter se expetendam. Quid sequatur, quid repugnet, vident. Quod quidem iam fit etiam in Academia. ',
  },
  {
    id: 1,
    logo: '/assets/press/guardian.svg',
    darkLogo: '/assets/press/guardian-dark.svg',
    text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Illa tamen simplicia, vestra versuta. Negat esse eam, inquit, propter se expetendam. Quid sequatur, quid repugnet, vident. Quod quidem iam fit etiam in Academia. ',
  },
  {
    id: 2,
    logo: '/assets/press/tnw.svg',
    darkLogo: '/assets/press/tnw.svg',
    text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Illa tamen simplicia, vestra versuta. Negat esse eam, inquit, propter se expetendam. Quid sequatur, quid repugnet, vident. Quod quidem iam fit etiam in Academia. ',
  },
  {
    id: 3,
    logo: '/assets/press/newguardian.svg',
    darkLogo: '/assets/press/newguardian-dark.svg',
    text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Illa tamen simplicia, vestra versuta. Negat esse eam, inquit, propter se expetendam. Quid sequatur, quid repugnet, vident. Quod quidem iam fit etiam in Academia. ',
  },
  {
    id: 4,
    logo: '/assets/press/theverge.svg',
    darkLogo: '/assets/press/theverge.svg',
    text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Illa tamen simplicia, vestra versuta. Negat esse eam, inquit, propter se expetendam. Quid sequatur, quid repugnet, vident. Quod quidem iam fit etiam in Academia. ',
  },
  {
    id: 5,
    logo: '/assets/press/theonion.svg',
    darkLogo: '/assets/press/theonion-dark.svg',
    text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Illa tamen simplicia, vestra versuta. Negat esse eam, inquit, propter se expetendam. Quid sequatur, quid repugnet, vident. Quod quidem iam fit etiam in Academia. ',
  },
]
