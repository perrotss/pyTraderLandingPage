export const contactBlockA = `
<template>
  <ContactForm />
</template>
`
