export const Props = `
<script setup lang="ts">
  
</script>
`

export const component = `
<template>
  
</template>
`
